<?php
  $password = "gymnazium";
?>
